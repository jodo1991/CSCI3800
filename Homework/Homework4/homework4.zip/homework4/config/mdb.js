/**
 * Created by Joseph on 3/30/2017.
 */

var mongo = require('mongoose');
mongo.connect('mongodb://tester:abc@ds147070.mlab.com:47070/moviedb');
var db = mongo.connection;
db.on('error', console.log.bind(console, 'connection error: '));
db.once('open', function(){
});

var Schema = mongo.Schema;

var movieSchema = new Schema({
    title : {type: String, required: true, unique: true},
    yearRel : {type: Number, required: true, min: 1800, max:2020},
    actors : {
        type: Array, required: true,
        validate: {
            validator: function (v) {
                return v.length > 2;
            },
            message: 'Need at least three actors!'
        }
    }
});

module.exports = mongo.model('movies', movieSchema);


