/**
 * Created by Joseph on 3/30/2017.
 */

var MovieDb = require('../../config/mdb');

module.exports = {
    getAll : getAll,
    getOne : getOne,
    postOne : postOne,
    deleteOne: deleteOne
};

function getAll(req,res){
    MovieDb.find({}, "title yearRel actors", function(err,response){
        if (err) throw err;
        res.json(response);
    });
}

function getOne(req,res){
    MovieDb.findOne({'title': req.query.title}, "title yearRel actors", function(err,response){
        if (err) console.log(err);
        else if (response == null) res.status(204).json();
        else res.json(response);
    });
}

function postOne(req,res){
    movie = new MovieDb({
        title: req.body.title,
        yearRel: req.body.year,
        actors: req.body.actors
    });
    movie.save(function(err){
        if (err) res.status(400).json(err.errors);
        else res.status(200).json(movie.title + " added to database");
    });
}

function deleteOne(req,res){
    MovieDb.remove({'title': req.query.title}, function(err,response){
        if(err) throw err;
        res.json(response);
    })
}