module.exports = {
    "MyVault": {
        "key": "githubPAT",
        "data": "8417343e8231981f507d5519f1c80374242515c615744e2bf11c1325cc19142e5928c0d272733f3e16142000776f63cb"
    }
};