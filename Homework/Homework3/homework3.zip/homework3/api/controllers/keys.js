module.exports = {
	"githubPAT": {
		"data": "b2e5fd08ca0e0c72f053c94b403b43b91a93e26459e8fb9bd2e9870fa8fc8e68269fe74ad0d85e13c444912fccb3ee48"
	}
};