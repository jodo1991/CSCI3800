'use strict';

var githubAPI = require("node-github");
var vault = require("avault").createVault(__dirname);

var github = new githubAPI({
  version: "3.0.0"
});

module.exports = {
  getUserInfo: getUserInfo
};

function getUserInfo(req, res) {
  authenticateGithub();
  github.user.get({}, function(err,res2){
      res.json({response: res2});
  })
}

function authenticateGithub(){
    vault.get('MyVault',function(token){
        github.authenticate({
            type: "oauth",
            token: token
        });
    });
}
