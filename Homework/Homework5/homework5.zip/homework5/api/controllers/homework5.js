/**
 * Created by Joseph on 4/14/2017.
 */

var MovieDb = require('../../config/mdb');
var Movie = MovieDb.movie;
var Review = MovieDb.review;
var async = require('async');

module.exports = {
    getAll : getAll,
    getOne : getOne,
    postMovie : postMovie,
    postReview : postReview,
    deleteOne: deleteOne
};

function getAll(req,res){
    Movie.find({}, {
        '_id': false,
        '__v': false
    }, function(err,response){
        if (err) res.status(400).json(err.errors);
        else if (response == null) res.status(204).json();
        else res.status(200).json(response);
    })
}

function getOne(req,res){
    async.parallel({
            movie: function (callback) {
                Movie.findOne({'title': req.query.title}, {'_id':false, '__v':false}, "title yearRel actors", function (err, response) {
                    callback(err, response);
                });
            },
            //get reviews if user wants them, timeout to make sure it returns after movie
            reviews: function (callback) {
                if (req.query.review)
                setTimeout(function() {
                    Review.find({'title': req.query.title}, {
                        '_id': false,
                        'title': false,
                        '__v': false
                    }, "reviewerName quote rating", function (err, response) {
                        //give message if no reviews were found
                        if (response.length == 0)
                            response = "No reviews found for " + req.query.title;
                        callback(err, response);
                    });
                }, 200);
                else callback();
            }
    }, function(err, response){
             if (err) res.status(400).json(err.errors);
             else if (response.movie == null) res.status(204).json();
             else res.json(response);
    });
}

function postMovie(req,res){
    movie = new Movie({
        title: req.body.title,
        yearRel: req.body.year,
        actors: req.body.actors
    });
    movie.save(function(err){
        if (err) res.status(400).json(err.errors);
        else res.status(200).json(movie.title + " added to database");
    });
}

function postReview(req,res){
    review = new Review({
        title: req.body.title,
        reviewerName: req.body.reviewerName,
        quote: req.body.quote,
        rating: req.body.rating
    });
    Movie.findOne({'title': review.title}, function(err,response){
        if (err) res.status(400).json(err.errors);
        else if (response === null) {
            res.status(404).json(review.title + " not found in the database. Review was not added.");
        }
        else
            review.save(function(err){
                if (err) res.status(400).json(err.errors);
                else res.status(200).json(review.title + " review added to database");
            });
    });
}

function deleteOne(req,res){
    Movie.remove({'title': req.query.title}, function(err,response){
        if(err) res.status(400).json(err.errors);
        else {
            Review.remove({'title':req.query.title}, function(err, response){
                if(err) throw(err)
            });
            res.status(200).json(response);
        }
    })
}